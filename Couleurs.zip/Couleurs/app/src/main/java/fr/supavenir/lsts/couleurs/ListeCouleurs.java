package fr.supavenir.lsts.couleurs;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import fr.supavenir.lsts.couleurs.db.DbHelper;


// TODO pouvoir modifier et supprimer la couleur sélectionnée dans la liste
// TODO en ajoutant deux éléments visibles comportant des îcones de type delete et edit


public class ListeCouleurs extends AppCompatActivity {

    private ListView lvListeCouleurs;
    private Button btnAjouterCouleur;
    private static AdaptateurCouleur adaptateur;

    ActivityResultLauncher<Intent> lanceurActiviteChoixCouleur = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(),
        new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == RESULT_OK) {
                    int a = result.getData().getIntExtra("a", 255);
                    int r = result.getData().getIntExtra("r", 255);
                    int v = result.getData().getIntExtra("v", 255);
                    int b = result.getData().getIntExtra("b", 255);
                    String nomCouleur = result.getData().getStringExtra("nom");
                    Log.i("COULEUR","couleur "+a+" , " + r + " , " + v +" , "+ b +" " + nomCouleur);
                    String requete = result.getData().getStringExtra("requete");
                    Couleur couleurToUse = new Couleur( a, r, v, b , nomCouleur );
                    if(requete.equals("AJOUTER")) {
                        if(adaptateur.ajouterCouleur(couleurToUse) == -1) {
                            Toast.makeText(ListeCouleurs.this, "Erreur: une couleur porte deja le nom '"+couleurToUse.getNom()+"'",Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        if(adaptateur.changerCouleur(adaptateur.getPositionEnCours() , couleurToUse, result.getData().getStringExtra("ancienNom")) < 0) {
                            Toast.makeText(ListeCouleurs.this, "Impossible de modifier cette couleur...",Toast.LENGTH_SHORT).show();
                        }
                    }
                } else if( result.getResultCode() == RESULT_CANCELED) {
                    Toast.makeText(ListeCouleurs.this, "Opération annulée", Toast.LENGTH_SHORT).show();
                }
                //actualisation de la liste des couleurs
                afficherLaListe();
            }
        }
    );


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView( R.layout.activite_liste_couleurs );

        btnAjouterCouleur = findViewById(R.id.btnAjouterCouleur);
        btnAjouterCouleur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentionChoixCouleur = new Intent(ListeCouleurs.this, ActiviteChoixCouleur.class);
                intentionChoixCouleur.putExtra("requete","AJOUTER");
                lanceurActiviteChoixCouleur.launch(intentionChoixCouleur);
            }
        });

        // recuperation des couleurs de la BDD
        afficherLaListe();
    }

    public void afficherLaListe() {
        ArrayList<Couleur> listCouleur = DbHelper.getInstance(ListeCouleurs.this).getCouleursFormDB(ListeCouleurs.this);
        Log.i("bdd", String.valueOf(listCouleur.size()));
        adaptateur = new AdaptateurCouleur(this, listCouleur);
        if(listCouleur.isEmpty()) {
            Toast.makeText(this,"La liste de couleur est vide",Toast.LENGTH_SHORT).show();
        } else {
            lvListeCouleurs = findViewById(R.id.lvCouleurs);
            lvListeCouleurs.setAdapter(adaptateur);
        }
    }

    public void getLanceurActiviteChoixCouleur(Intent intent) {
        lanceurActiviteChoixCouleur.launch(intent);
    }

    public void setPositionEncours(int pos) {  adaptateur.setPositionEnCours(pos); }


    private void createAndPopulateDb() {
        /*DbHelper dbHelper = new DbHelper(ListeCouleurs.this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        db.beginTransaction();
        for(int i =0;i<3;i++) {
            String nom = String.format(Locale.FRANCE,"couleur%d", i+1);
            int a = (int) (Math.random()*255);
            int r = (int) (Math.random()*255);
            int g = (int) (Math.random()*255);
            int b = (int) (Math.random()*255);

            ContentValues contentValues = new ContentValues();
            contentValues.put("nom",nom);
            contentValues.put("a",a);
            contentValues.put("r",r);
            contentValues.put("g",g);
            contentValues.put("b",b);

            db.insert("CouleurARGB", null, contentValues);
            setPositionEncours(i);
        }
        db.setTransactionSuccessful();
        db.endTransaction();
        db.close();*/
    }

    private boolean checkDbState() {
        SharedPreferences sharedPreferences = getPreferences(MODE_PRIVATE);
        Log.i("dbUpToDate", String.valueOf(sharedPreferences.getBoolean("dbUpToDate", false)));
        return sharedPreferences.getBoolean("dbUpToDate", false);
    }


    private void writeDbState() {
        SharedPreferences sharedPreferences = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("dbUpToDate", true);
        editor.apply();
    }
}