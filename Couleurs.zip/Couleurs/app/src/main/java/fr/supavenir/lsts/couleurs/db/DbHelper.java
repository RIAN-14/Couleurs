package fr.supavenir.lsts.couleurs.db;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ArrayList;

import fr.supavenir.lsts.couleurs.Couleur;
import fr.supavenir.lsts.couleurs.ListeCouleurs;


public class DbHelper extends SQLiteOpenHelper {
    final static String TAG="DbHelper";
    // La version de la base de données est ici définie à 2,
    // pour pouvoir illustrer le processus d'upgrade
    private final static int dbVersion = 2;
    private final static String dbName="mainDB";
    private static DbHelper INSTANCE;

    private ListeCouleurs listCouleurs;
    private Context ContextListCouleur;

    private DbHelper(Context context) {
            super(context, dbName, null, dbVersion);
            this.ContextListCouleur = context;
    }

    public static DbHelper getInstance(Context context) {
        if(INSTANCE != null)
            return INSTANCE;
        else
            return new DbHelper(context);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE "+ Couleur.CouleurDBName +" (id INTEGER PRIMARY KEY AUTOINCREMENT" +
                                        ", "+Couleur.alphaDBName+ " TEXT" +
                                        ", "+Couleur.rougeDBName+ " TEXT" +
                                        ", "+Couleur.vertDBName+ " TEXT" +
                                        ", "+Couleur.bleuDBName+ " TEXT" +
                                        ", "+Couleur.nomDBName+ " TEXT" +
                ");"
        );
        Log.d(TAG,"la méthode onCreate de DbHelper a été exécutée");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        for (int indexVersion = oldVersion; indexVersion < newVersion;
             indexVersion++) {
            int nextVersion = indexVersion + 1;
            switch (nextVersion) {
                case 2:
                    // TO DO si version2
                    break;
            }

        }
        Log.d(TAG,"la méthode onUpgrade de DbHelper a été exécutée");
    }

    //                          //
    //       Method CRUD        //
    //                          //


    public int createCouleur(Couleur couleur) {
        //TODO
        int valRetour = 1;
        DbHelper dbHelper = getInstance(this.ContextListCouleur);
        if(getColorIdByNom(couleur.getNom()) == -1) {
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            db.beginTransaction();
            ContentValues contentValues = new ContentValues();
            contentValues.put(Couleur.nomDBName, couleur.getNom());
            contentValues.put(Couleur.alphaDBName, couleur.getA());
            contentValues.put(Couleur.rougeDBName, couleur.getR());
            contentValues.put(Couleur.vertDBName, couleur.getV());
            contentValues.put(Couleur.bleuDBName, couleur.getB());

            db.insert(Couleur.CouleurDBName, null, contentValues);
            db.setTransactionSuccessful();
            db.endTransaction();
            db.close();
        } else {
            valRetour = -1;
        }
        return valRetour;
    }

    @SuppressLint("Range")
    public ArrayList<Couleur> getCouleursFormDB(Context context) {
        String sqlQuery = MessageFormat.format("Select * from {0} order by {1}", Couleur.CouleurDBName, Couleur.nomDBName);
        getInstance(context).ContextListCouleur = context;
        DbHelper dbHelper = getInstance(context);
        Cursor cursor = dbHelper.getReadableDatabase().rawQuery(sqlQuery, null);
        ArrayList<Couleur> arrayList = new ArrayList<>(cursor.getCount());
        while (cursor.moveToNext()) {
            String nom = cursor.getString(cursor.getColumnIndex("nom"));
            int a = cursor.getInt(cursor.getColumnIndex("a"));
            int r = cursor.getInt(cursor.getColumnIndex("r"));
            int g = cursor.getInt(cursor.getColumnIndex("g"));
            int b = cursor.getInt(cursor.getColumnIndex("b"));

            Couleur couleur = new Couleur(a,r,g,b,nom);
            arrayList.add(couleur);
        }
        cursor.close();
        return arrayList;
    }

    public int updateCouleurByNom(Couleur couleurToUpdate, String ancienNom) {
        //TODO
        int valRetour = 1;
        DbHelper dbHelper = getInstance(this.ContextListCouleur);

        ContentValues contentValues = new ContentValues();
        contentValues.put(Couleur.nomDBName,couleurToUpdate.getNom());
        contentValues.put(Couleur.alphaDBName,couleurToUpdate.getA());
        contentValues.put(Couleur.rougeDBName,couleurToUpdate.getR());
        contentValues.put(Couleur.vertDBName,couleurToUpdate.getV());
        contentValues.put(Couleur.bleuDBName,couleurToUpdate.getB());

        int id = getColorIdByNom(ancienNom);

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.beginTransaction();
        if(id > 0)
            db.update(Couleur.CouleurDBName, contentValues, "id = '"+id+"'",null);
        else
            valRetour = -1;
        db.setTransactionSuccessful();
        db.endTransaction();
        db.close();
        return valRetour;
    }

    @SuppressLint("Range")
    public int getColorIdByNom(String nom) {
        String sqlQuery = MessageFormat.format("Select id from {0} where {1} =?", Couleur.CouleurDBName, Couleur.nomDBName);
        Log.i(TAG, "getColorIdByNom query: "+sqlQuery+" "+nom);
        DbHelper dbHelper = getInstance(this.ContextListCouleur);
        Cursor cursor = dbHelper.getReadableDatabase().rawQuery(sqlQuery, new String[]{nom});
        int id = -1;
        if(cursor.moveToFirst())
            id = cursor.getInt(cursor.getColumnIndex("id"));
        cursor.close();
        Log.i(TAG, "getColorIdByNom: id ="+id);
        return id;
    }

    public void deleteCouleurByNom(String nom) {
        String[] nomArray = {nom};

        DbHelper dbHelper = getInstance(this.ContextListCouleur);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(Couleur.CouleurDBName,Couleur.nomDBName+"='"+nom+"'",null);
        db.close();
    }
}

